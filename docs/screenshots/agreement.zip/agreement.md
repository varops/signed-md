
# Software development services agreement

This agreement is made between **Automaze Ltd** ("Provider") and Acme Ltd ("Client").

## 1. Services

Provider will deliver software development services as agreed in writing between the parties.

## 2. Fees

| Item | Amount |
|---|---|
| Monthly retainer | $1,000.00 |

Invoices are due within 14 days.

## 3. Termination

Either party may end this agreement with 30 days' written notice.

## 4. Signatures

**Client**

Name: {{client.full_name:text}}

Signature: {{client.signature:signature}}

Date: {{client.date:date}}

**Provider**

Signature: {{provider.signature:signature}}
